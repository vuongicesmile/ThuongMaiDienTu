$(function (){
    $('.select2_init').select2({
        'placeholder':'Chọn vai trò'
    })
})


